import os
import pandas as pd
from xml.etree import ElementTree as ET

# 定义输入和输出路径
input_dir = 'output_strings'
output_file_path = 'StringXML.xlsx'

# 初始化一个空的字典来存储所有字符串
data = {'name': []}
languages = set()

# 读取values或values-en下的strings.xml，收集所有name
values_folder = os.path.join(input_dir, 'values')
if not os.path.exists(values_folder):
    values_folder = os.path.join(input_dir, 'values-en')

strings_file = os.path.join(values_folder, 'strings.xml')
if os.path.exists(strings_file):
    tree = ET.parse(strings_file)
    root = tree.getroot()
    
    for string in root.findall('string'):
        name = string.get('name')
        if name not in data['name']:
            data['name'].append(name)

# 初始化每种语言的列表为None
for folder in os.listdir(input_dir):
    folder_path = os.path.join(input_dir, folder)
    if os.path.isdir(folder_path):
        lang_code = folder.replace('values-', '') if folder != 'values' else 'en'
        languages.add(lang_code)
        data[lang_code] = [None] * len(data['name'])

# 填充数据
for folder in os.listdir(input_dir):
    folder_path = os.path.join(input_dir, folder)
    if os.path.isdir(folder_path):
        lang_code = folder.replace('values-', '') if folder != 'values' else 'en'
        strings_file = os.path.join(folder_path, 'strings.xml')
        
        if os.path.exists(strings_file):
            tree = ET.parse(strings_file)
            root = tree.getroot()
            
            for string in root.findall('string'):
                name = string.get('name')
                text = string.text
                if name in data['name']:
                    index = data['name'].index(name)
                    data[lang_code][index] = text

# 将字典转换为DataFrame
df = pd.DataFrame(data)

# 保存到Excel文件
df.to_excel(output_file_path, index=False)

print(f"{output_file_path} 已生成。")
