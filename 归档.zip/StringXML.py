import os
import pandas as pd

# 定义输入和输出路径
input_file_path = 'StringXML.xlsx'
output_dir = 'output_strings'

# 读取Excel文件，确保所有内容作为字符串读取，并将NaN替换为空字符串
df = pd.read_excel(input_file_path, dtype=str).fillna('')

# # 找到包含 'name' 的行的索引
# name_row_index = df.index[df['name'] == 'name'][0]

# # 从该行开始读取数据
# df = df.iloc[name_row_index + 1:]

# 创建输出目录
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 遍历DataFrame，按语言生成strings.xml文件
for lang_code in df.columns[1:]:
    # 确定文件夹名称
    if lang_code == 'en':
        values_folder = os.path.join(output_dir, 'values')
    else:
        values_folder = os.path.join(output_dir, f'values-{lang_code}')

    # 创建对应的values文件夹
    if not os.path.exists(values_folder):
        os.makedirs(values_folder)

    # 开始构建XML字符串
    xml_content = ['<?xml version="1.0" encoding="utf-8"?>\n<resources xmlns:tools="http://schemas.android.com/tools" tools:ignore="ResourceName">']
    for index, row in df.iterrows():
        name = row['name']
        text = row[lang_code]
        formatted = 'false' if ('%' in text) else 'true'
        # print(f"Processing - Name: {name}, Language: {lang_code}, Text: {text}")  # 打印参数
        if formatted == 'false':
            xml_content.append(f'    <string name="{name}" formatted="false">{text}</string>')
        else:
            xml_content.append(f'    <string name="{name}">{text}</string>')

    xml_content.append('</resources>')

    # 将XML内容合并为一个字符串
    pretty_xml_str = "\n".join(xml_content)

    # 打印生成的XML字符串（调试用）
    # print(f"Generated XML for {lang_code}:\n{pretty_xml_str}")

    # 写入文件
    with open(os.path.join(values_folder, 'strings.xml'), 'w', encoding='utf-8') as f:
        f.write(pretty_xml_str)

print("多语言strings.xml文件已生成在目录:", output_dir)
